<div class="row">
    <div class="col-md-12 pt-2">
        <form action="/searchimages" method="post" id="search_form">
            <?php echo e(csrf_field()); ?>

            <div class="form-group label-floating">
                <label class="control-label">Search by Image Caption (Type and Hit Enter)</label>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-search"></i></span>
                    </div>
                    <input type="text" name="s" class="form-control" value="<?php echo e(old('s')); ?>">
                </div>
                
            </div>
        </form>
    </div>
</div>
<div class="row" id="image_browse" style="max-height: 500px; overflow: scroll;">
    <?php $__currentLoopData = $userpics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
	$picpath = '/storage/images/' . auth()->user()->id . '/thumb_240' . '/' . $pic->pic_path;
	$this_caption = "";
    $this_caption = ($pic->products()->count() ? $pic->products[0]->pivot->caption : '');
    ?>
    <div class="col-sm-6 col-md-3">
        <div class="thumbnail">
            <div class="fixedbox">
                <img src="<?php echo e($picpath); ?>" class="sitepics" style="width: 100%" id="pic-<?php echo e($pic->id); ?>" data-sizes="<?php echo e($pic->lg); ?>-<?php echo e($pic->md); ?>-<?php echo e($pic->sm); ?>-<?php echo e($pic->xs); ?>"
                    data-caption="<?php echo e($this_caption); ?>" />
            </div>
            <div class="caption">
                <?php echo e($this_caption); ?> &nbsp;
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
