

<div class="container">
    <div class="row">
        <?php $__currentLoopData = $banners->banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            
            <div class="banner banner-image">
                <a href="#">
                    <img src="/storage/banners/<?php echo e($banner->banner); ?>"  alt="<?php echo e($banner->title); ?>">
                </a>
                <div class="banner-meta">
                    <a href="<?php echo e($banner->link); ?>"><?php echo e($banner->title); ?></a>

                    <!-- <span class="banner-price">Starting at <span>$999</span></span> -->
                </div><!-- End .banner-meta -->
            </div><!-- End .banner -->
        </div><!-- End .col-md-4 -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div><!-- End .row -->
</div><!-- End .container -->