<?php $__currentLoopData = $bannersV->banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        
        <div class="col-md-12">
            
            <div class="banner banner-image">
                <a href="<?php echo e($banner->link); ?>" target="_blank">
                    <img src="/storage/banners/<?php echo e($banner->banner); ?>"  alt="<?php echo e($banner->title); ?>">
                </a>

            </div><!-- End .banner -->
        </div><!-- End .col-md-4 -->
        
    </div><!-- End .row -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
