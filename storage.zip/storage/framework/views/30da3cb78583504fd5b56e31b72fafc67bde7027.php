

<div class="container">
    <div class="row">
        <?php $__currentLoopData = $bannersH2->banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            
            <div class="banner banner-image">
                <a href="<?php echo e($banner->link); ?>" target="_blank">
                    <img src="/storage/banners/<?php echo e($banner->banner); ?>"  alt="<?php echo e($banner->title); ?>">
                </a>

            </div><!-- End .banner -->
        </div><!-- End .col-md-4 -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div><!-- End .row -->
</div><!-- End .container -->