<?php $__env->startSection('pagetitle'); ?>
<?php echo e($product->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extracss'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb" class="breadcrumb-nav">
    <div class="container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/"><i class="icon-home"></i></a></li>
            
        </ol>
    </div>
</nav>
<input type="hidden" id="cart_product_id" value="<?php echo e($product->id); ?>" />
<div class="container">
    <div class="row">
        <div class="col-lg-9">
            <div class="product-single-container product-single-default">
                <div class="row">
                    <div class="col-lg-7 col-md-6 product-single-gallery">
                        <div class="product-slider-container product-item">
                            <div class="product-single-carousel owl-carousel owl-theme">
                                <?php $__currentLoopData = $product->pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    if($key == 0) {
                                        $firstpic = $pic->pic_path;
                                    }
                                ?>
                                <div class="product-item">
                                    <img class="product-single-image" src="/storage/images/<?php echo e($product->user_id); ?>/original/<?php echo e($pic->pic_path); ?>"
                                        data-zoom-image="/storage/images/<?php echo e($product->user_id); ?>/original/<?php echo e($pic->pic_path); ?>" />
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <span class="prod-full-screen">
                                <i class="icon-plus"></i>
                            </span>
                        </div>
                        <div class="prod-thumbnail row owl-dots" id='carousel-custom-dots'>
                            <?php $__currentLoopData = $product->pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-3 owl-dot">
                                <img src="/storage/images/<?php echo e($product->user_id); ?>/thumb_400/<?php echo e($pic->pic_path); ?>" />
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="col-lg-5 col-md-6">
                        <div class="product-single-details">
                            <h1 class="product-title"><?php echo e($product->name); ?></h1>

                            <div class="product-desc">
                                <p><?php echo $product->description; ?></p>
                            </div>

                            <div style="margin-bottom: 2rem" class="product-filters-container">
                                <small>Prices</small>

                                <div id="product-price-detail" style="padding-top:2rem">
                                    <div class="price-box">
                                        <?php
                                            $first_product_price  = $product->prices->first();
                                            $regular = $first_product_price->regular;
                                            $discounted = $first_product_price->discounted;

                                        ?>

                                        <?php if( $regular == $discounted): ?>
                                        <span class="product-price">Rs. <?php echo e($regular); ?></span>
                                        <?php else: ?>
                                        <span class="old-price">Rs. <?php echo e($regular); ?></span>
                                        <span class="product-price">Rs. <?php echo e($discounted); ?></span>
                                        <?php endif; ?>
                                        
                                    </div>    
                                </div>
                            </div>

                            <div class="sticky-header">
                                <div class="container">
                                    <div class="sticky-img">
                                        <img class="sticky-img-" src="/storage/images/<?php echo e($product->user_id); ?>/thumb_400/<?php echo e($firstpic); ?>" />
                                    </div>
                                    <div class="sticky-detail">
                                        <div class="sticky-product-name">
                                            <h2 class="product-title"><?php echo e($product->name); ?></h2>
                                            <div class="price-box">

                                                <?php if( $regular == $discounted): ?>
                                                <span class="product-price" id="sticky-product-price">Rs. <?php echo e($regular); ?></span> 
                                                <?php else: ?>
                                                <span class="old-price" id="sticky-old-price">Rs. <?php echo e($regular); ?></span>
                                                <span class="product-price" id="sticky-product-price">Rs. <?php echo e($discounted); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>
                                    <a href="javascript:void(0)" class="paction add-cart btn-add-to-cart" title="Add to Cart">
                                        <span>Add to Cart</span>
                                    </a>
                                </div>
                            </div><!-- end .sticky-header -->

                            <div class="product-action product-all-icons">
                                <div class="product-single-qty">
                                    <input class="horizontal-quantity form-control" id="productQty" type="text">
                                </div><!-- End .product-single-qty -->

                                <a href="javascript:void(0)" class="paction add-cart btn-add-to-cart" title="Add to Cart">
                                    <span>Add to Cart</span>
                                </a>
                                <a href="javascript:void(0)" class="paction add-wishlist" title="Add to Wishlist">
                                    <span>Add to Wishlist</span>
                                </a>

                            </div><!-- End .product-action -->

                            <div class="product-single-share">
                                <label>Share:</label>
                                <!-- www.addthis.com share plugin-->
                                <div class="addthis_inline_share_toolbox"></div>
                            </div><!-- End .product single-share -->
                        </div><!-- End .product-single-details -->
                    </div><!-- End .col-lg-5 -->
                </div><!-- End .row -->
            </div><!-- End .product-single-container -->

            <div class="product-single-tabs">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="product-tab-desc" data-toggle="tab" href="#product-desc-content"
                            role="tab" aria-controls="product-desc-content" aria-selected="true">Description</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="product-tab-tags" data-toggle="tab" href="#product-tags-content" role="tab"
                            aria-controls="product-tags-content" aria-selected="false">Specifications</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="product-desc-content" role="tabpanel" aria-labelledby="product-tab-desc">
                        <div class="product-desc-content">
                                <?php echo $product->description; ?>

                        </div><!-- End .product-desc-content -->
                    </div><!-- End .tab-pane -->

                    <div class="tab-pane fade" id="product-tags-content" role="tabpanel" aria-labelledby="product-tab-tags">
                        <div class="product-tags-content">
                                <?php echo $product->specification; ?>

                        </div><!-- End .product-tags-content -->
                    </div><!-- End .tab-pane -->

                </div><!-- End .tab-content -->
            </div><!-- End .product-single-tabs -->
        </div><!-- End .col-lg-9 -->

        <div class="sidebar-overlay"></div>
        <div class="sidebar-toggle"><i class="icon-sliders"></i></div>
        <aside class="sidebar-product col-lg-3 padding-left-lg mobile-sidebar">
            <div class="sidebar-wrapper">
                

                <div class="widget widget-info">
                    <ul>
                        <li>
                            <i class="icon-shipping"></i>
                            <h4>SHIPPING<br>AVAILABLE</h4>
                        </li>
                        <li>
                            <i class="icon-us-dollar"></i>
                            <h4>100% MONEY<br>BACK GUARANTEE</h4>
                        </li>
                        <li>
                            <i class="icon-online-support"></i>
                            <h4>ONLINE<br>SUPPORT 24/7</h4>
                        </li>
                    </ul>
                </div><!-- End .widget -->

                <div class="widget widget-banner">
                    <div class="banner banner-image">
                        <a href="#">
                            <img src="/assets/images/banners/banner-sidebar.jpg" alt="Banner Desc">
                        </a>
                    </div><!-- End .banner -->
                </div><!-- End .widget -->

                <div class="widget widget-featured">
                    <h3 class="widget-title">Featured Products</h3>

                    <div class="widget-body">
                        <div class="owl-carousel widget-featured-products">
                            <div class="featured-col">
                                <?php $__currentLoopData = $featureds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$featured): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key < 3): ?>
                                <?php
                                    if(count($featured->product->pics) > 0) {
                                        $image_path = '<img src="/storage/images/'.$featured->product['user_id'].'/thumb_400'.'/' . $featured->product->pics->first()->pic_path .'" />';
                                    } else {
                                        $image_path = "&nbsp;";
                                    }
                                    $regular = $featured->product->prices->min('regular');
                                    $discounted = $featured->product->prices->min('discounted');
                                    $off = (($regular -$discounted)/$regular)*100;
                                ?>
                                <div class="product product-sm">
                                    <figure class="product-image-container">
                                        <a href="/product/<?php echo e($featured->product['slug']); ?>" class="product-image">
                                            <?php echo $image_path; ?>

                                        </a>
                                    </figure>
                                    <div class="product-details">
                                        <h2 class="product-title">
                                            <a href="/product/<?php echo e($featured->product['slug']); ?>"><?php echo e($featured->product['name']); ?></a>
                                        </h2>
                                        <div class="ratings-container">
                                            <div class="product-ratings">
                                                <span class="ratings" style="width:80%"></span><!-- End .ratings -->
                                            </div><!-- End .product-ratings -->
                                        </div><!-- End .product-container -->
                                        <div class="price-box">
                                            <span class="product-price">Rs. <?php echo e($discounted); ?></span>
                                        </div><!-- End .price-box -->
                                    </div><!-- End .product-details -->
                                </div><!-- End .product -->
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div><!-- End .featured-col -->


                        </div><!-- End .widget-featured-slider -->
                    </div><!-- End .widget-body -->
                </div><!-- End .widget -->
            </div>
        </aside><!-- End .col-md-3 -->
    </div><!-- End .row -->
</div><!-- End .container -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrajs'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.d11', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>