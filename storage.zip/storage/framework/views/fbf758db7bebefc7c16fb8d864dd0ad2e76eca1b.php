<div class="product-single-container product-single-default product-quick-view container">
        <div class="row">
            <div class="col-lg-6 col-md-6 product-single-gallery">
                <div class="product-slider-container product-item">
                    <div class="product-single-carousel owl-carousel owl-theme">
                        <?php $__currentLoopData = $product->pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-item">
                            <img class="product-single-image" src="/storage/images/<?php echo e($product->user_id); ?>/original/<?php echo e($pic->pic_path); ?>" 
                            data-zoom-image="/storage/images/<?php echo e($product->user_id); ?>/original/<?php echo e($pic->pic_path); ?>"/>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <!-- End .product-single-carousel -->
                </div>
                <div class="prod-thumbnail row owl-dots" id='carousel-custom-dots'>
                    <?php $__currentLoopData = $product->pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-3 owl-dot">
                        <img src="/storage/images/<?php echo e($product->user_id); ?>/thumb_400/<?php echo e($pic->pic_path); ?>"/>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div><!-- End .col-lg-7 -->
    
            <div class="col-lg-6 col-md-6">
                <div class="product-single-details">
                    <h1 class="product-title"><?php echo e($product->name); ?></h1>
    
                    
    
                    
    
                    <div class="product-desc">
                        <p><?php echo e($product->description); ?></p>
                    </div><!-- End .product-desc -->
                    


                    <div style="margin-bottom: 2rem" class="product-filters-container">
                        <div class="dropdown">
                            <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Product Price
                            </button>
                            <div class="dropdown-menu custom-dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <?php $__currentLoopData = $product->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item custom-dropdown-link changeprice" 
                                    href="javascript:void(0)" 
                                    id="<?php echo e($price->id); ?>" 
                                    data-regular = "<?php echo e($price->regular); ?>" 
                                    data-discounted = "<?php echo e($price->discounted); ?>" 
                                    >
                                    <?php echo e($price->attributes); ?>

                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                          </div>
                          <div id="product-price-detail">
                                <div class="product-single-filter">
                                        <label>Colors:</label>
                                        <ul class="config-swatch-list">
                                            <li class="active">
                                                <a href="#" style="background-color: #6085a5;"></a>
                                            </li>
                                            <li>
                                                <a href="#" style="background-color: #ab6e6e;"></a>
                                            </li>
                                            <li>
                                                <a href="#" style="background-color: #b19970;"></a>
                                            </li>
                                            <li>
                                                <a href="#" style="background-color: #11426b;"></a>
                                            </li>
                                        </ul>
                                    </div>
                          </div>
                    </div>


    

    
                    <div class="product-action">
                        <div class="product-single-qty">
                            <input class="horizontal-quantity form-control" type="text">
                        </div><!-- End .product-single-qty -->
    
                        <a href="cart.html" class="paction add-cart" title="Add to Cart">
                            <span>Add to Cart</span>
                        </a>
                        <a href="#" class="paction add-wishlist" title="Add to Wishlist">
                            <span>Add to Wishlist</span>
                        </a>
                        <a href="#" class="paction add-compare" title="Add to Compare">
                            <span>Add to Compare</span>
                        </a>
                    </div><!-- End .product-action -->
    
                    <div class="product-single-share">
                        <label>Share:</label>
                        <!-- www.addthis.com share plugin-->
                        <div class="addthis_inline_share_toolbox"></div>
                    </div><!-- End .product single-share -->
                </div><!-- End .product-single-details -->
            </div><!-- End .col-lg-5 -->
        </div><!-- End .row -->
    </div><!-- End .product-single-container -->    
