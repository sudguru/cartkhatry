
<li class="<?php echo e($currentPage == 'dashboard' ? 'active' : ''); ?>"><a href="<?php echo e(route('account.dashboard')); ?>">Account Dashboard</a></li>
<li class="<?php echo e($currentPage == 'accountinfo' ? 'active' : ''); ?>"><a href="<?php echo e(route('account.info')); ?>">Account Information</a></li>
<li><a href="/auth/password/change">Change Password</a></li>
<li class="<?php echo e($currentPage == 'addressbook' ? 'active' : ''); ?>"><a href="/account/addresses">Address Book</a></li>
<li class="dropdown-divider"></li>
<li class="<?php echo e($currentPage == 'clientorders' ? 'active' : ''); ?>"><a href="/account/customer/orders">My Orders</a></li>
<li class="<?php echo e($currentPage == 'clientmessages' ? 'active' : ''); ?>"><a href="#">My Messages</a></li>
