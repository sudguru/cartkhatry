<?php $__env->startSection('pagetitle'); ?>
<?php echo e($setting->site_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
    $cur = $_GET['cur'] ?? 'NPR';
    $cur = filter_var($cur, FILTER_SANITIZE_STRING);
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8" style="padding:0">
                <?php echo $__env->make('partials.home-slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-md-4">
                <?php echo $__env->make('partials.vertical-banners', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div><!-- End .container -->
    <?php echo $__env->make('partials.horizontal-banners1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.home-featured', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="mb-3"></div><!-- margin -->
    <?php echo $__env->make('partials.horizontal-banners2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.home-top', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="mb-3"></div><!-- margin -->
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.d11', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>