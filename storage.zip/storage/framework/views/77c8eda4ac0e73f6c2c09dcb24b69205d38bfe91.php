<header class="header">
    <div class="header-middle">
        <div class="container">
            <div class="header-left">
                    <button class="mobile-menu-toggler" type="button">
                            <i class="icon-menu"></i>
                        </button>
                <a href="/" class="logo">
                    <img src="/assets/images/logo.png" alt="">
                </a>
            </div><!-- End .header-left -->



            <div class="header-right">
                
                <div class="header-contact">
                    <span><?php echo e(auth()->user()->name); ?></span>
                    <a href="tel:#"><strong>Admin Section</strong></a>
                </div><!-- End .header-contact -->

            </div><!-- End .header-right -->
        </div><!-- End .container -->
    </div><!-- End .header-middle -->
    <div class="header-bottom sticky-header">
        <div class="container">
            <nav class="main-nav">
                <ul class="menu sf-arrows">
                    <li class="<?php echo e($active == 'Dashboard' ? 'active' : ''); ?>"><a href="/adm">DASHBOARD</a></li>
                    <li class="<?php echo e($active == 'Basic' ? 'active' : ''); ?>"><a href="#" class="sf-with-ul">Basic</a>
                        <ul>
                            <li><a href="<?php echo e(route('promo.index')); ?>">Promo Links</a></li>
                            <li><a href="<?php echo e(route('info.index')); ?>">Info Boxes</a></li>
                            <li>
                                <a href="#">Contents</a>
                                <ul>
                                    <li><a href="<?php echo e(route('contenttype.index')); ?>">Content Types</a></li>
                                    <li><a href="<?php echo e(route('content.index')); ?>">Content</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">Banners</a>
                                <ul>
                                    <li><a href="<?php echo e(route('bannertype.index')); ?>">Banner Types</a></li>
                                    <li><a href="<?php echo e(route('banner.index')); ?>">Banners</a></li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(route('outlet.index')); ?>">Outlets</a></li>
                        </ul>
                    </li>

                    <li class="<?php echo e($active == 'Products' ? 'active' : ''); ?>"><a href="#" class="sf-with-ul">SHOP</a>
                        <ul>
                            <li><a href="<?php echo e(route('product.create')); ?>">Add New Products</a></li>
                            <li><a href="<?php echo e(route('product.index')); ?>">All Products</a></li>
                            <li><a href="<?php echo e(route('order.index')); ?>">Manage Orders</a></li>
                            <li class="dropdown-divider"></li>
                            <li><a href="<?php echo e(route('category.index')); ?>">Product Categories</a></li>
                            <li><a href="<?php echo e(route('paymentmethod.index')); ?>">Payment Methods</a></li>
                            <li><a href="<?php echo e(route('size.index')); ?>">Product Sizes</a></li>
                            <li><a href="<?php echo e(route('brand.index')); ?>">Brands</a></li>
                            <li><a href="<?php echo e(route('currency.index')); ?>">Currencies</a></li>
                        </ul>
                    </li>
                    <li class="<?php echo e($active == 'Lists' ? 'active' : ''); ?>"><a href="#" class="sf-with-ul">Lists</a>
                        <ul>
                            <li><a href="<?php echo e(route('productlist.index')); ?>?listname=new">New Products</a></li>
                            <li><a href="<?php echo e(route('productlist.index')); ?>?listname=featured">Featured Products</a></li>
                        </ul>
                    </li>
                    <li class="<?php echo e($active == 'Users' ? 'active' : ''); ?>"><a href="<?php echo e(route('userdetail.index')); ?>">Manage Users</a></li>
                    <li class="<?php echo e($active == 'Settings' ? 'active' : ''); ?>"><a href="<?php echo e(route('setting.index')); ?>">Settings</a></li>
                    <li class="float-right">
                        <a id="posted" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                            if (! confirm('Are You Sure?')) { return false; } 
                            else { document.getElementById('logout-form').submit(); }">
                            SIGN OUT
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                    <li class="float-right"><a href="/">BACK TO SITE HOME</a></li>
                </ul>
            </nav>
        </div><!-- End .header-bottom -->
    </div><!-- End .header-bottom -->
</header><!-- End .header -->
