<div class="mobile-menu-overlay"></div><!-- End .mobil-menu-overlay -->

<div class="mobile-menu-container">
    <div class="mobile-menu-wrapper">
        <span class="mobile-menu-close"><i class="icon-cancel"></i></span>
        <nav class="mobile-nav">
            <ul class="mobile-menu">
                <li class="<?php echo e($active == 'Dashboard' ? 'active' : ''); ?>"><a href="/adm">DASHBOARD</a></li>
                <li class="<?php echo e($active == 'Basic' ? 'active' : ''); ?>"><a href="#" class="sf-with-ul">Basic</a>
                    <ul>
                        <li><a href="<?php echo e(route('promo.index')); ?>">Top Messages</a></li>
                        <li><a href="<?php echo e(route('info.index')); ?>">Info Boxes</a></li>
                        <li>
                            <a href="#">Contents</a>
                            <ul>
                                <li><a href="<?php echo e(route('contenttype.index')); ?>">Content Types</a></li>
                                <li><a href="<?php echo e(route('content.index')); ?>">Content</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Banners</a>
                            <ul>
                                <li><a href="<?php echo e(route('bannertype.index')); ?>">Banner Types</a></li>
                                <li><a href="<?php echo e(route('banner.index')); ?>">Banners</a></li>
                            </ul>
                        </li>
                        <li><a href="<?php echo e(route('outlet.index')); ?>">Outlets</a></li>
                    </ul>
                </li>

                <li><a href="#" class="sf-with-ul">SHOP</a>
                    <ul>
                        <li><a href="<?php echo e(route('category.index')); ?>">Product Categories</a></li>
                        <li><a href="<?php echo e(route('paymentmethod.index')); ?>">Payment Methods</a></li>
                        <li><a href="<?php echo e(route('product.index')); ?>">Products</a></li>
                        <li><a href="<?php echo e(route('order.index')); ?>">Manage Orders</a></li>
                    </ul>
                </li>
                <li><a href="#" class="sf-with-ul">Lists</a>
                    <ul>
                        <li><a href="<?php echo e(route('productlist.index')); ?>?listname=new">New Products</a></li>
                        <li><a href="<?php echo e(route('productlist.index')); ?>?listname=featured">Featured Products</a></li>
                    </ul>
                </li>
                <li><a href="<?php echo e(route('userdetail.index')); ?>">Manage Users</a></li>
                <li><a href="<?php echo e(route('setting.index')); ?>">Settings</a></li>
                <li class="float-right">
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                if (! confirm('Are You Sure?')) { return false; } 
                                else { document.getElementById('logout-form').submit(); }">
                        SIGN OUT
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
                <li class="float-right"><a href="/">BACK TO SITE HOME</a></li>
            </ul>
        </nav><!-- End .mobile-nav -->


    </div><!-- End .mobile-menu-wrapper -->
</div><!-- End .mobile-menu-container -->
