<?php $__env->startSection('pagetitle'); ?>
Banner Types - Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extracss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/snackbar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center pb-3" style="border-bottom: 2px solid #ccc">
    <h2 class="pt-2 mb-0">Banner Types</h2>
    <span class="ml-auto">
        <a href="/adm/bannertype/create" class="btn btn-outline-success btn-sm">
            <i class="fas fa-plus"></i> Add New
        </a>
    </span>
</div>

<?php if($message = Session::get('success')): ?>
<div id="snackbar"><?php echo e($message); ?></div>
<?php endif; ?>
<div class="row justify-content-center mt-0">
    <div class="col-md-12">
        <ul class="list-group mt-2" id="my-ui-list">
            <?php $__currentLoopData = $bannertypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bannertype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex" data-id="<?php echo e($bannertype->id); ?>" style="cursor: move">
                <a href='<?php echo e(route('bannertype.edit',$bannertype->id)); ?>'><?php echo e($bannertype->bannertype); ?></a>
                <span class="ml-auto">
                    <a href="/adm/bannertype/<?php echo e($bannertype->id); ?>" onclick="event.preventDefault();
                    if ( confirm('You are about to delete this item ?\n \'Cancel\' to stop, \'OK\' to delete.') ) { document.getElementById('delete-form-<?php echo e($bannertype->id); ?>').submit();}return false;">
                        <i class="fas fa-trash text-danger"></i>
                    </a>
                    <form id="delete-form-<?php echo e($bannertype->id); ?>" action="/adm/bannertype/<?php echo e($bannertype->id); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('delete')); ?>

                        <input type="hidden" name="id" value="<?php echo e($bannertype->id); ?>" />
                    </form>
                </span>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<div class="mb-5"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrajs'); ?>
<script src="<?php echo e(asset('assets/js/sortable.min.js')); ?>"></script>
<script>
    var x = document.getElementById("snackbar");
    if (x) {
        x.className = "show";
        setTimeout(function () {
            x.className = x.className.replace("show", "");
        }, 3000);
    } 
    

    var list = document.getElementById("my-ui-list");
    Sortable.create(list, {
        animation: 150,
        store: {
            get: function (sortable) {
                var order = sortable.toArray();
            },

            set: function (sortable) {
                var order = sortable.toArray();
                var data = {
                    order: order,
                    _token: '<?php echo csrf_token() ?>'
                };

                $.ajax({
                    type:'POST',
                    url:'/adm/bannertype/sortit',
                    data: data,
                    success:function(data){
                        console.log(data);
                    }
                });
            }
        }
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>