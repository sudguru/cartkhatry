<div class="container">
    
    <div class="home-slider-container">
        <div class="home-slider owl-carousel owl-theme owl-theme-light">
            
            <?php $__currentLoopData = $hpSliders->banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="home-slide">
            <a href="<?php echo e($banner->link); ?>" target="_blank"><div class="slide-bg owl-lazy"  data-src="storage/banners/<?php echo e($banner->banner); ?>"></div></a><!-- End .slide-bg -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><!-- End .container -->