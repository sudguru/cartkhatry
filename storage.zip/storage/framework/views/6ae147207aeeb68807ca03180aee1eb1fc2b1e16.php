<?php $__env->startSection('pagetitle'); ?>
Product LIst - Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extracss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/snackbar.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center">
    <h2 class="pt-2 mb-0">Product LIst</h2>
    <span class="ml-auto">
        <a href="/adm/productlist/create?listname=<?php echo e($listname); ?>" class="btn btn-outline-success btn-sm">
            <i class="fas fa-plus"></i> Add New
        </a>
    </span>
</div>
<?php if($message = Session::get('success')): ?>
<div id="snackbar"><?php echo e($message); ?></div>
<?php endif; ?>

<div class="row justify-content-start">
    <div class="col-md-12">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a href="<?php echo e(route('productlist.index')); ?>?listname=new" class="nav-link <?php echo e($listname == 'new' ? 'active' : ''); ?>">NEW</a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('productlist.index')); ?>?listname=featured" class="nav-link <?php echo e($listname == 'featured' ? 'active' : ''); ?>">FEATURED</a>
            </li>
        </ul>
    </div>
</div>



<div class="row justify-content-center mt-3">
    
    
    <div class="col-md-7">
        <h4>Products in the List</h4>
        <ul class="list-group mt-2" id="my-ui-list">
            <?php $__currentLoopData = $productlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex align-items-center justify-content-between" data-id="<?php echo e($productlist->id); ?>"
                style="cursor: move">
                <span style="width: 70%">
                    <a href='<?php echo e(route('productlist.edit',$productlist->id)); ?>'><?php echo e($productlist->product['name']); ?></a>
                </span>
                <span class="ml-auto">
                    <a href="/adm/productlist/<?php echo e($productlist->id); ?>" onclick="event.preventDefault();
                    if ( confirm('You are about to delete this item ?\n \'Cancel\' to stop, \'OK\' to delete.') ) { document.getElementById('delete-form-<?php echo e($productlist->id); ?>').submit();}return false;">
                        <i class="fas fa-trash text-danger"></i>
                    </a>
                    <form id="delete-form-<?php echo e($productlist->id); ?>" action="/adm/productlist/<?php echo e($productlist->id); ?>" method="POST"
                        style="display: none;">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('delete')); ?>

                        <input type="hidden" name="id" value="<?php echo e($productlist->id); ?>" />
                    </form>
                </span>
            </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="col-md-1">&nbsp;</div>
    <div class="col-md-4">
        <h4>Available Products</h4>
        <ul class="list-group mt-3">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex align-items-center justify-content-between" id="p-<?php echo e($product->id); ?>">
                <span style="width: 70%">
                    <?php echo e($product->name); ?>

                </span>
                <span class="ml-auto">
                    <a href='javascript:void(0)' class="addProduct"><i class="fas fa-plus"></i> Add</a>
                </span>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

</div>
<div class="mb-5"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrajs'); ?>
<script src="<?php echo e(asset('assets/js/sortable.min.js')); ?>"></script>
<script>
    var x = document.getElementById("snackbar");
    if (x) {
        x.className = "show";
        setTimeout(function () {
            x.className = x.className.replace("show", "");
        }, 3000);
    }


    var list = document.getElementById("my-ui-list");
    Sortable.create(list, {
        animation: 150,
        store: {
            get: function (sortable) {
                var order = sortable.toArray();
            },

            set: function (sortable) {
                var order = sortable.toArray();
                var data = {
                    order: order,
                    _token: '<?php echo csrf_token() ?>'
                };

                $.ajax({
                    type: 'POST',
                    url: '/adm/productlist/sortit',
                    data: data,
                    success: function (data) {
                        console.log(data);
                    }
                });
            }
        }
    });
</script>

<script>
    $(document).ready(function() {
        $('.addProduct').on('click', function(){
            var rowid = $(this).parent().parent().attr('id');
            var product_id = rowid.split('-')[1];
            $('#'+rowid).remove();
            var data = {
                listname: "<?php echo e($listname); ?>",
                product_id: product_id,
                _token: '<?php echo csrf_token() ?>'
            };
            $.ajax({
                type: 'POST',
                url: '/adm/productlist',
                data: data,
                success: function (data) {
                    dataObj = JSON.parse(data);
                    if (data) {
                        var item = '<li class="list-group-item d-flex align-items-center justify-content-between" ' +
                            'data-id="'+dataObj.id+'" style="cursor: move">' +
                            '<span style="width: 70%">' +
                                '<a href="#">'+dataObj.name+'</a>' +
                            '</span>' +
                            '<span class="ml-auto">' +
                                '<a href="/adm/productlist/'+dataObj.id+'" onclick="event.preventDefault();' +
                                'if ( confirm(\'You are about to delete this item?\\n \\\'Cancel\\\' to stop, \\\'OK\\\' to delete.\') ) ' +
                                '{ document.getElementById(\'delete-form-'+dataObj.id+'\').submit();}return false;">' +
                                    '<i class="fas fa-trash text-danger"></i>' +
                                '</a>' +
                                '<form id="delete-form-'+dataObj.id+'" action="/adm/productlist/'+dataObj.id+'" method="POST" style="display: none;">' +
                                    '<input type="hidden" name="_token" value="'+dataObj.token+'">'+
                                    '<input type="hidden" name="_method" value="delete">'+
                                    '<input type="hidden" name="id" value="'+dataObj.id+'" />' +
                                '</form>' +
                            '</span>' +
                        '</li>';
                        console.log(item);
                        $('#my-ui-list').prepend(item);
                    }
                }
            });
        })
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>