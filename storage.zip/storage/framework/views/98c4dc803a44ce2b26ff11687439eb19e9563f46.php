<div class="mobile-menu-overlay"></div><!-- End .mobil-menu-overlay -->

    <div class="mobile-menu-container">
        <div class="mobile-menu-wrapper">
            <span class="mobile-menu-close"><i class="icon-cancel"></i></span>
            <nav class="mobile-nav">
                <ul class="mobile-menu">
                    <li class="active"><a href="/">Home</a></li>
                    <li>
                        <a href="/categories" class="sf-with-ul">Categories</a>
                        <ul>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="/category/<?php echo e($parent->slug); ?>"><?php echo e($parent->category); ?></a>
                                <?php if($parent->children->count() == 0): ?> </li> <?php endif; ?>
                            <?php if($parent->children->count() > 0): ?>
                            <ul>
                                <?php $__currentLoopData = $parent->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="/catgory/<?php echo e($child->slug); ?>"><?php echo e($child->category); ?></a>
                                    <?php if($child->children->count() == 0): ?> </li> <?php endif; ?>
                                <?php if($child->children->count() > 0): ?>
                                <ul>
                                    <?php $__currentLoopData = $child->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="/catgory/<?php echo e($grandchild->slug); ?>"><?php echo e($grandchild->category); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                </li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                </li>
                <li>
                    <a href="/products" class="sf-with-ul">Products</a>
                </li>
                <li>
                    <a href="/outlets" class="sf-with-ul">Outlets</a>
                    <ul>
                        <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="/outlet/<?php echo e($outlet->slug); ?>"><?php echo e($outlet->outlet); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li><a href="/account/dashboard">Track Order</a></li>

                <li><a href="/account/dashboard">Customer Care</a></li>


                <li class="float-right"><a href="/sales">Sales !</a></li>
                </ul>
            </nav><!-- End .mobile-nav -->
            <div class="mb-5"></div>
            <div class="social-icons">
                <a href="#" class="social-icon" target="_blank"><i class="icon-facebook"></i></a>
                <a href="#" class="social-icon" target="_blank"><i class="icon-twitter"></i></a>
                <a href="#" class="social-icon" target="_blank"><i class="icon-instagram"></i></a>
            </div><!-- End .social-icons -->
        </div><!-- End .mobile-menu-wrapper -->
    </div><!-- End .mobile-menu-container -->