<?php $__env->startSection('pagetitle'); ?>
Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extracss'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/snackbar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('success')): ?>
<div id="snackbar"><?php echo e($message); ?></div>
<?php endif; ?>
<div class="container">


    <div class="d-flex justify-content-between">
        <h2>Products</h2>
        <a class="btn btn-sm btn-primary" style="height:36px; padding: .6rem 1.5rem" href="<?php echo e(route('product.create')); ?>">New</a>
    </div>
    <div class="table-responsive mt-2 mb-4">
        <table class="table table-striped" id="myTable">
            <thead>
                <tr>
                    <td>SN</td>
                    <td>Name</td>
                    <td>Brand</td>
                    <td>Category</td>
                    <td>Delivery</td>
                    <td>Delivery Charge</td>
                    <td>Del</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><a href="<?php echo e(route('product.edit', $product->slug)); ?>"><?php echo e($product->name); ?></a></td>
                    <td><?php echo e($product->brand['brand']); ?></td>
                    <td><?php echo e($product->category['category']); ?></td>
                    <td><?php echo e($product->delivery_available == 0 ? 'N/A' : $product->delivery_day_from . ' - ' . $product->delivery_day_to . ' days'); ?></td>
                    <td>
                        <?php echo e($product->delivery_charge_local); ?> / 
                        <?php echo e($product->delivery_charge_intercity); ?> / 
                        <?php echo e($product->delivery_charge_intl); ?>

                    </td>
                    <td>
                        <a href="<?php echo e(route('product.destroy', $product->id)); ?>" onclick="event.preventDefault();
                                if ( confirm('You are about to delete this item ?\n \'Cancel\' to stop, \'OK\' to delete.') ) { document.getElementById('delete-form-<?php echo e($product->id); ?>').submit();}return false;">
                            <i class="fas fa-trash"></i>
                        </a>
                        <form id="delete-form-<?php echo e($product->id); ?>" action="<?php echo e(route('product.destroy', $product->id)); ?>" method="POST"
                            style="display: none;">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('DELETE')); ?>

                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>

</div><!-- End .container -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrajs'); ?>

<script src="<?php echo e(asset('assets/js/bs4datatables.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $('#myTable').DataTable({
            "columns": [
                null,
                null,
                null,
                null,
                null,
                null,
                {
                    "orderable": false
                },

            ]
        });

        var x = document.getElementById("snackbar");
        if (x) {
            x.className = "show";
            setTimeout(function () {
                x.className = x.className.replace("show", "");
            }, 3000);
        }
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>