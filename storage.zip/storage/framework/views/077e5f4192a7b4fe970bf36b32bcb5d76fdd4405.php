<?php $__env->startSection('pagetitle'); ?>
Add Banner - admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center">
    <h2 class="pt-2 mb-0">Banner - Add</h2>

</div>

    <form action="<?php echo e(route('banner.store')); ?>" method="POST" enctype="multipart/form-data" id="thisForm" autocomplete="off"
        novalidate class="mb-1">

        <?php echo csrf_field(); ?>
        <div class="row justify-content-center mt-3">
        <div class="col-md-4" style="text-align: center">
            <img src="/assets/images/banner-placeholder.jpg" style="width:100%; margin: 0 auto; cursor: pointer" id="picImage" />
            <small><em>Click the banner above to Add/Change</em></small>
            <input type="file" name="banner" id="banner" class="<?php echo e($errors->has('banner') ? 'is-invalid' : ''); ?>" style="display: none" accept="image/x-png,image/gif,image/jpeg" />
            <?php if($errors->has('banner')): ?>
            <span class="required" role="alert">
                <br><strong><?php echo e($errors->first('banner')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
        <?php
        if(old('bannertype_id')):
            $selectedBannerTypeId = old('bannertype_id');
        else:
            $selectedBannerTypeId = $bannertype_id;
        endif
        ?>
        <div class="col-md-8">
            <div class="form-group">
                <label for="bannertype_id">Banner Type <span class="required">*</span></label>
                <select id="bannertype_id" name="bannertype_id" class="form-control<?php echo e($errors->has('bannertype_id') ? ' is-invalid' : ''); ?>">
                    <option value="0" data-nt="1" data-nst="1">Select Banner Type</option>
                    <?php $__currentLoopData = $bannertypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bannertype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($bannertype->id); ?>" data-nt="<?php echo e($bannertype->needsTitle); ?>" data-nst="<?php echo e($bannertype->needsSubtitle); ?>"
                        <?php echo e($selectedBannerTypeId == $bannertype->id ? 'selected' : ''); ?>>
                        <?php echo e($bannertype->bannertype); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
                <?php if($errors->has('bannertype_id')): ?>
                
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('bannertype_id')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="title">Title</label>
                <input id="title" type="text" class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" name="title"
                    value="<?php echo e(old('title')); ?>" autofocus>

                <?php if($errors->has('title')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('title')); ?></strong>
                </span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="subtitle">Subitle</label>
                <input id="subtitle" type="text" class="form-control<?php echo e($errors->has('subtitle') ? ' is-invalid' : ''); ?>"
                    name="subtitle" value="<?php echo e(old('subtitle')); ?>">

                <?php if($errors->has('subtitle')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('subtitle')); ?></strong>
                </span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="link">Link</label>
                <input id="link" type="text" class="form-control<?php echo e($errors->has('link') ? ' is-invalid' : ''); ?>" name="link"
                    value="<?php echo e(old('link')); ?>">
                <small id="linkHelp" class="form-text text-muted">Must Start with http:// or https:// but can be empty</small>
                <?php if($errors->has('link')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('link')); ?></strong>
                </span>
                <?php endif; ?>
            </div>

            <div class="form-footer" style="margin-top: 0; padding-top:0">
                <button type="submit" class="btn btn-primary btn-md">Save Banner</button>
                <a class="btn btn-light btn-md" href="<?php echo e(route('banner.index')); ?>?bannertype_id=<?php echo e($bannertype_id); ?>">Cancel</a>
            </div><!-- End .form-footer -->
        </div>
    </div>
    </form>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrajs'); ?>
<script>
    $(document).ready(function () {
        //at page load
        

        $('#bannertype_id').on('change',function () {
            var selected = $(this).find('option:selected');
            var needsTitle = selected.data('nt');
            var needsSubtitle = selected.data('nst');
            enableDisable(needsTitle, needsSubtitle);
        });
        $('#bannertype_id').val('<?php echo e($bannertype_id); ?>').trigger('change');
        function enableDisable(needsTitle, needsSubtitle) {
            if (needsTitle) {
                $("#title").prop('disabled', false);
            } else {
                // $('#title').val('');
                $("#title").prop('disabled', true);
            }
            if (needsSubtitle) {
                $("#subtitle").prop('disabled', false);
            } else {
                // $('#subtitle').val('');
                $("#subtitle").prop('disabled', true);
            }
        }

        $('#picImage').on('click', function () {
            $('#banner').click();
        });

        $('#banner').on('change', function (e) {

            var file = document.getElementById('banner').files[0];
            var picImage = document.getElementById('picImage');
            var reader = new FileReader();
            reader.onload = function (e) {
                imageDataURL = e.target.result;
                picImage.src = imageDataURL;
                //   var image = new Image();
                //   image.src = imageDataURL;
                //   image.onload = function (imageEvent) {
                //       // Resize the image
                //       var canvas = document.createElement('canvas'),
                //           max_size = 300,
                //           width = image.width,
                //           height = image.height;
                //       if (width > height) {
                //           if (width > max_size) {
                //               height *= max_size / width;
                //               width = max_size;
                //           }
                //       } else {
                //           if (height > max_size) {
                //               width *= max_size / height;
                //               height = max_size;
                //           }
                //       }
                //       canvas.width = width;
                //       canvas.height = height;
                //       canvas.getContext('2d').drawImage(image, 0, 0, width, height);
                //       var dataUrl = canvas.toDataURL('image/jpeg');

                // }

            }
            reader.readAsDataURL(file);
        });

    });

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>