<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Municipality;

class MunicipalityController extends Controller
{
    public function __construct() {
        return $this->middleware('auth');
    }

    public function index() {
        $municipalities = Municipality::orderBy('municipality')->get();
        return view('municipality.index', compact('municipalities'));
    }

    public function create() {
        return view('municipality.add');
    }

    public function store(Request $request) {
        $this->performValidation($request);
        $municipality = Municipality::create([
            'municipality' => $request->municipality,
            'municipality_nepali' => $request->municipality_nepali
        ]);
        return redirect()->route('municipality.index')->with('success', 'Municipality Successfully Added');
    }

    public function destroy(){
        Municipality::destroy(request('id'));
        return back()->with('success','Municipality deleted successfully.');
    }

    public function edit(Municipality $municipality) {

        return view('municipality.edit', compact('municipality'));
    }

    public function update(Request $request, Municipality $municipality) {
        $this->performValidation($request);
        $municipality->update([
            'municipality' => $request->municipality,
            'municipality_nepali' => $request->municipality_nepali
        ]);
        return redirect()->route('municipality.index')->with('success', 'Municipality Successfully Update.');
    }

    public function performValidation(Request $request) {
        $request->validate([
            'municipality' => 'required|min:2',
            'municipality_nepali' => 'required|min:2'
        ]);
    }
}
