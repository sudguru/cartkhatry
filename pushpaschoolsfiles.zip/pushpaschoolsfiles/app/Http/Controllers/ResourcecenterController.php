<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Resourcecenter;
class ResourcecenterController extends Controller
{
    public function __construct() {
        return $this->middleware('auth');
    }

    public function index() {
        $resourcecenters = Resourcecenter::orderBy('resourcecenter')->get();
        return view('resourcecenter.index', compact('resourcecenters'));
    }

    public function create() {
        return view('resourcecenter.add');
    }

    public function store(Request $request) {
        $this->performValidation($request);
        $resourcecenter = Resourcecenter::create([
            'resourcecenter' => $request->resourcecenter,
            'resourcecenter_nepali' => $request->resourcecenter_nepali
        ]);
        return redirect()->route('resourcecenter.index')->with('success', 'Resourcecenter Successfully Added');
    }

    public function destroy(){
        Resourcecenter::destroy(request('id'));
        return back()->with('success','Resourcecenter deleted successfully.');
    }

    public function edit(Resourcecenter $resourcecenter) {

        return view('resourcecenter.edit', compact('resourcecenter'));
    }

    public function update(Request $request, Resourcecenter $resourcecenter) {
        $this->performValidation($request);
        $resourcecenter->update([
            'resourcecenter' => $request->resourcecenter,
            'resourcecenter_nepali' => $request->resourcecenter_nepali
        ]);
        return redirect()->route('resourcecenter.index')->with('success', 'Resourcecenter Successfully Update.');
    }

    public function performValidation(Request $request) {
        $request->validate([
            'resourcecenter' => 'required|min:2',
            'resourcecenter_nepali' => 'required|min:2'
        ]);
    }
}
