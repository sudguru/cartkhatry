<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Recent;
use App\School;
class HomeController extends Controller
{
    public function __construct() {
        return $this->middleware('auth');
    }

    public function index() {
        $schools = School::orderBy('name')->pluck('name', 'id');
        $recents  = Recent::orderBy('created_at', 'desc')->take(100)->get();
        return view('home', compact('recents','schools'));
    }

    public function manageimage() {
        $directory = storage_path('app/public/schoolpics');
        $scanned_directory = array_diff(scandir($directory), array('..', '.','.DS_Store'));
        $imagefiles = json_encode($scanned_directory, 0);
        $schools = School::orderBy('name')->pluck('name', 'id');
        return view('manageimage', compact('schools', 'imagefiles'));
    }

    public function setphoto(Request $request) {
        $school = School::find($request->school_id);
        $school->update([
            'photo' => $request->photo
        ]);
        return $request->school_id;

    }

    public function printwithimage() {
        return view('printwithimage');
    }
    
}
