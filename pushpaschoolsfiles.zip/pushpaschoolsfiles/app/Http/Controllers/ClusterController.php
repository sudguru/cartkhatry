<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cluster;

class ClusterController extends Controller
{
    public function __construct() {
        return $this->middleware('auth');
    }

    public function index() {
        $clusters = Cluster::orderBy('cluster')->get();
        return view('cluster.index', compact('clusters'));
    }

    public function create() {
        return view('cluster.add');
    }

    public function store(Request $request) {
        $this->performValidation($request);
        $cluster = Cluster::create([
            'cluster' => $request->cluster,
            'cluster_nepali' => $request->cluster_nepali
        ]);
        return redirect()->route('cluster.index')->with('success', 'Cluster Successfully Added');
    }

    public function destroy(){
        Cluster::destroy(request('id'));
        return back()->with('success','Cluster deleted successfully.');
    }

    public function edit(Cluster $cluster) {

        return view('cluster.edit', compact('cluster'));
    }

    public function update(Request $request, Cluster $cluster) {
        $this->performValidation($request);
        $cluster->update([
            'cluster' => $request->cluster,
            'cluster_nepali' => $request->cluster_nepali
        ]);
        return redirect()->route('cluster.index')->with('success', 'Cluster Successfully Update.');
    }

    public function performValidation(Request $request) {
        $request->validate([
            'cluster' => 'required|min:2',
            'cluster_nepali' => 'required|min:2'
        ]);
    }

}
