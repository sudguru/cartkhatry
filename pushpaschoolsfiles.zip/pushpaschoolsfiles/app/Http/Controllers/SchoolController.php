<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\School;
use App\Resourcecenter;
use App\Cluster;
use App\Municipality;
use App\Recent;

class SchoolController extends Controller
{
    protected $guarded = [];

    public function __construct() {
        return $this->middleware('auth');
    }

    public function index() {
        $schools = School::orderBy('name')->get();
        return view('school.index', compact('schools'));
    }
    public function show(School $school) {
        return view('school.show', compact('school'));
    }
    public function create() {
        $municipalities = Municipality::orderBy('municipality')->get();
        $clusters = Cluster::orderBy('cluster')->get();
        $resourcecenters = Resourcecenter::orderBy('resourcecenter')->get();
        return view('school.add', [
            'municipalities' => $municipalities,
            'resourcecenters' => $resourcecenters,
            'clusters' => $clusters
        ]);
    }

    public function store(Request $request) {
        $this->performValidation($request);

        // $image = $request->file('photo');
        // $photo = null;
        // if($image) {
        //     $photo = time() . '.' . $image->getClientOriginalExtension();
        //     $image->storeAs('public/images', $photo);    
        // }
        $photo = null;
        if($request->photodataurl) {
            $photo = time(). '.' . 'jpg';
            \Image::make($request->photodataurl)->save(storage_path('app/public/schoolpics/').$photo);
        }
        
        
        
        $school = School::create([
            'name' => $request->name,
            'principal' => $request->principal,
            'municipality_id' => $request->municipality_id,
            'ward_no' => $request->ward_no,
            'address' => $request->address,
            'office_no' => $request->office_no,
            'mobile_no' => $request->mobile_no,
            'classes_upto' => $request->classes_upto,
            'cluster_id' => $request->cluster_id,
            'email' => $request->email,
            'contact_person' => $request->contact_person,
            'contact_no' => $request->contact_no,
            'estd' => $request->estd,
            'post_box' => $request->post_box,
            'home_no' => $request->home_no,
            'cdo' => $request->cdo,
            'resourcecenter_id' => $request->resourcecenter_id,
            'school_type' => $request->school_type,
            'photo' => $photo,
            'notes' => $request->notes,
            'website' => $request->website
        ]);

        $this->addToRecent($school->id, $school->name, 'Added');

        return redirect()->route('home')->with('success', 'School Successfully Added."');
    }

    public function edit(School $school) {
        $municipalities = Municipality::orderBy('municipality')->get();
        $clusters = Cluster::orderBy('cluster')->get();
        $resourcecenters = Resourcecenter::orderBy('resourcecenter')->get();
        return view('school.edit', [
            'municipalities' => $municipalities,
            'resourcecenters' => $resourcecenters,
            'clusters' => $clusters,
            'school' => $school
        ]);
    }

    public function update(Request $request, School $school) {
        $this->performValidation($request);
        $image = $request->file('photo');
        $photo = null;
        // if($image) {
        //     $photo = time() . '.' . $image->getClientOriginalExtension();
        //     $image->storeAs('public/images', $photo);    
        // } else {
        //     $photo = $school->photo;
        // }
        $photo = null;
        if($request->photodataurl) {
            $photo = time(). '.' . 'jpg';
            \Image::make($request->photodataurl)->save(storage_path('app/public/schoolpics/').$photo);
        } else {
            $photo = $school->photo;
        }
        $school->update([
            'name' => $request->name,
            'principal' => $request->principal,
            'municipality_id' => $request->municipality_id,
            'ward_no' => $request->ward_no,
            'address' => $request->address,
            'office_no' => $request->office_no,
            'mobile_no' => $request->mobile_no,
            'classes_upto' => $request->classes_upto,
            'cluster_id' => $request->cluster_id,
            'email' => $request->email,
            'contact_person' => $request->contact_person,
            'contact_no' => $request->contact_no,
            'estd' => $request->estd,
            'post_box' => $request->post_box,
            'home_no' => $request->home_no,
            'cdo' => $request->cdo,
            'resourcecenter_id' => $request->resourcecenter_id,
            'school_type' => $request->school_type,
            'photo' => $photo,
            'notes' => $request->notes,
            'website' => $request->website
        ]);
        $this->addToRecent($school->id, $school->name, 'Edited');
        return redirect()->route('home')->with('success', 'School Successfully Updated."');
    }

    public function destroy(){
        $school = School::find(request('id'));
        School::destroy(request('id'));
        $this->addToRecent($school->id, $school->name, 'Deleted');
        return redirect()->route('home')->with('success', 'School Successfully Deleted."');
    }

    public function performValidation(Request $request){
        $request->validate([
            'name' => 'required|min:7',
            'principal' => 'required|min:5',
            'municipality_id' => 'required|not_in:0',
            'cluster_id' => 'required|not_in:0',
            'resourcecenter_id' => 'required|not_in:0',
            'email'=> 'nullable|email',
            'website' => 'nullable|url',
            'classes_upto' => 'nullable|numeric',
            'estd' => 'nullable|numeric',
            'ward_no' => 'nullable|numeric'
        ]);
    }

    private function addToRecent($school_id, $name, $task) {
        if($task == 'Deleted') {
            Recent::where('school_id', $school_id)->delete();
        }
        Recent::create([
            'school_id' => $school_id,
            'name' => $name,
            'task' => $task      
        ]);
    }
}
