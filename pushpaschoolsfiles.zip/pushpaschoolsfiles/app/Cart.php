<?php 
// Route::get('/add-to-cart/{id}', 'CartController@addtocart);

public function addtocart(Request $request, $id) {
    $product = Product::ginf($id);
    $oldCart = Session::has('cart') ? Session::get('cart') : null;
    $cart = new Cart($oldCart);
    $cart->add($product, $prodct->id);
    $request->session()->put('cart', $cart);
    return redirect()->route('product.index');
}

public function showcart(Request $request) {
    if(!$request->session()->has('cart')) {
        return view('shop.shopptingcart', ['products' => null]);
    }
    $oldCart = $request->session()->get('cart');
    $cart = new Cart($oldCart);
    return view('shop.shoppingcart', [
        'products'] => $cart->items), 
        'totalPrice' => $cart->totalPrice
    ]);
}
// Model
// Cart.php

// namespace App;

// class Cart {
//     public $items = null;
//     public $totalQty = 0;
//     public $totalPrice = 0;

//     public function __construct($oldCart) {
//         if($oldCart) {
//             $this->items = $oldCart->items;
//             $this->totalQty = $oldCart->totalQty;
//             $this->totalPrice = $oldCart->totalPrice;
//         }
//     }

//     public function add($item, $id) { //$qty as argument
//         $storedItem = ['qty' => 0, 'price' => $item->price, 'item' => $item];
//         if($this->items) {
//             if(array_key_exits($id, $this->items)) {
//                 $storedItem = $this->items[$id];
//             }
//         }
//         $storedItem['qty']++; // + $qty;
//         $storedItem['price'] = $item->price * $storedItem['qty'];
//         $this->items[$id] = $storedItem;
//         $this->totalQty++;
//         $this->totalPrice += $tiem->price; 
//     }
// }


@if(Session::has('cart'))

@foreach ($products as $key => $product) {
    <span>{{$product['qty']}}</span>
    <span>{{$product['item']['title'] }}</span>
}
@endif