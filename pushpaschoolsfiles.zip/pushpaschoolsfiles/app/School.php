<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class School extends Model
{
    protected $guarded = [];

    public function resourcecenter() {
        return $this->belongsTo('App\Resourcecenter');
    }

    public function municipality() {
        return $this->belongsTo('App\Municipality');
    }

    public function cluster() {
        return $this->belongsTo('App\Cluster');
    }
}
