@extends('layouts.app')
@section('pagetitle')
Dashboard
@endsection

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h4>Manage Images for School</h4>
            
            <div class="form-group">
                <input class="typeahead form-control" id="typeahead">
            </div>
            <div id="results">

            </div>

        </div>
    </div>
</div>
@endsection

@section('extrajs')
<script src="{{ asset('js/bootstrap3-typeahead.min.js') }}"></script>
<script src="{{ asset('js/fuzzyset.js') }}"></script>
<script>
    $(document).ready(function () {
        var imagefiles = {!!$imagefiles!!};
        var images = [];
        for (var key in imagefiles) {
            if (imagefiles.hasOwnProperty(key)) {
                images.push(imagefiles[key]);
            }
        }


        var schools_object = {!!$schools!!}
        var schoolsarray = [];
        for (var key in schools_object) {
            if (schools_object.hasOwnProperty(key)) {
                schoolsarray.push(schools_object[key] + "~" + key);
            }
        }
        $(".typeahead").typeahead({
            source: schoolsarray
        });
        
        $('#typeahead').on('keyup', function(e){
            if(e.keyCode == 8) {
                $(this).val('');
            }
        });
        


        $('#typeahead').on('change', function(){
            var school_id = $(this).val().split('~')[1];
            var school = $(this).val().split('~')[0];

            school = school.replace("Higher","").replace("Boarding","").replace("Secondary","").replace("English","");
            
            var results = '';
            var x = 0;
            
            a = FuzzySet(images, false, 2, 2);
            founds = a.get(school);
            founds.forEach(function(f) {

                results += '<div class="float-left px-3">'+
                        '<img src="/storage/schoolpics/'+f[1]+'" id="'+f[1]+'~'+school_id+'"  class="foundImages rounded" style="width: 180px">'+
                        '<p  style="width: 180px; word-break: break-all">' + f[1] + '</p>' +
                        '</div>';
            })
            // founds.forEach(function(image){
                
            //     var lowerimage = image.toLowerCase().replace("-", "");
            //     console.log(lowerimage, school);
            //     var x = lowerimage.includes(school.trim());
            //     console.log(x);
            //     if(x) {
            //         // results += image + ', ' + x + '<br/>'
                    
            //     }
            // })
            $('#results').html(results);
        });
        
        

        $('body').on('click', '.foundImages', function(){
            var id = $(this).attr('id');
            var school_id = id.split('~')[1];
            var photo = id.split('~')[0];
            data = {
                school_id: school_id,
                photo: photo,
                _token: '<?php echo csrf_token() ?>'
            };
            $.ajax({
                type:'POST',
                url:'/setphoto',
                data: data,
                success:function(data){
                    alert('Image Set !!!')
                }
            });
        })
        


    });

</script>
@endsection
