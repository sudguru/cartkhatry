@extends('layouts.app')

@section('pagetitle')
Add New Cluster
@endsection

@section('content')
<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-8">
            <h3>Add New Cluster</h3>
            <form action="{{route('cluster.store')}}" method="POST">
                @csrf
                <div class="form-group mt-4">
                    <label for="cluster">Cluster</label>
                    <input id="cluster" name="cluster" value="{{old('cluster')}}" class="form-control {{ $errors->has('cluster') ? 'is-invalid' : '' }}" />
                    @if($errors->has('cluster'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{$errors->first('cluster') }}</strong>
                    </span>
                    @endif
                </div>

                <div class="form-group">
                    <label for="cluster_nepali">Cluster (In Nepali)</label>
                    <input id="cluster_nepali" name="cluster_nepali" value="{{old('cluster_nepali')}}" class="form-control {{ $errors->has('cluster_nepali') ? 'is-invalid' : '' }}" />
                    @if($errors->has('cluster_nepali'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{$errors->first('cluster_nepali') }}</strong>
                    </span>
                    @endif
                </div>
                <button type="submit" class="btn btn-primary">Add</button>
                <a href="{{route('cluster.index')}}" class="btn btn-light">Cancel</a>
            </form>
        </div>
    </div>
</div>
@endsection