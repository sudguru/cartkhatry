@extends('layouts.app')

@section('pagetitle')
Clusters
@endsection

@section('extracss')
<link rel="stylesheet" href="{{ asset('/css/snackbar.css') }}">
@endsection

@section('content')
@if ($message = Session::get('success'))
<div id="snackbar">{{ $message }}</div>
@endif
<div class="container">
    <div class="d-flex align-items-center">
        <h3>Clusters</h3>
        <a class="btn btn-sm btn-primary ml-auto" href="{{route('cluster.create') }}">NEW</a>
    </div>
    <div class="table-responsive mt-3">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>SN</th>
                    <th>Cluster</th>
                    <th>In Nepali</th>
                    <th>Del</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($clusters as $key=>$cluster)
                <tr>
                    <td>{{$key+1}}</td>
                    <td><a href="{{route('cluster.edit', $cluster->id) }}">{{$cluster->cluster}}</a></td>
                    <td>{{$cluster->cluster_nepali}}</td>
                    <td>
                        <a href="/cluster/{{ $cluster->id }}" onclick="event.preventDefault();
                            if ( confirm('You are about to delete this item ?\n \'Cancel\' to stop, \'OK\' to delete.') ) { document.getElementById('delete-form-{{$cluster->id}}').submit();}return false;">
                            <i class="fas fa-trash text-danger"></i>
                        </a>
                        <form id="delete-form-{{$cluster->id}}" action="/cluster/{{ $cluster->id }}" method="POST"
                            style="display: none;">
                            @csrf
                            {{ method_field('delete') }}
                            <input type="hidden" name="id" value="{{ $cluster->id }}" />
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        <hr>
    </div>
</div>
@endsection

@section('extrajs')
<script>
    var x = document.getElementById("snackbar");
    if (x) {
        x.className = "show";
        setTimeout(function () {
            x.className = x.className.replace("show", "");
        }, 3000);
    }
</script>
@endsection