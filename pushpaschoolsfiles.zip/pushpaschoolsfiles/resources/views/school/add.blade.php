@extends('layouts.app')

@section('pagetitle')
Add New School
@endsection

@section('extracss')
<link rel="stylesheet" href="{{ asset('css/summernote.min.css') }}">
<link rel="stylesheet" href="{{ asset('css/customize_summernote.css') }}">
@endsection
@section('content')
<div class="container">
    <h3>Add New School</h3>
    {{$errors}}
    <form action="{{ route('school.store') }}" method ="POST"  enctype="multipart/form-data" >
        @csrf
    <ul class="nav nav-tabs mt-4" id="myTab" role="tablist">
        <li class="nav-item">
          <a class="nav-link active" id="basic-tab" data-toggle="tab" href="#basic" role="tab" aria-controls="basic" aria-selected="true">Basic <span id="basic-progress"></span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="official-tab" data-toggle="tab" href="#official" role="tab" aria-controls="official" aria-selected="false">Official <span id="official-progress"></span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="address-tab" data-toggle="tab" href="#addresst" role="tab" aria-controls="address" aria-selected="false">Address <span id="address-progress"></span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="info-tab" data-toggle="tab" href="#info" role="tab" aria-controls="info" aria-selected="false">Additional Info <span id="info-progress"></span></a>
          </li>
      </ul>
      <div class="tab-content pt-4" id="myTabContent">
        <div class="tab-pane fade show active" id="basic" role="tabpanel" aria-labelledby="home-tab">
            @include('school.partials.basic')
        </div>
        <div class="tab-pane fade" id="official" role="tabpanel" aria-labelledby="profile-tab">
            @include('school.partials.official')
        </div>
        <div class="tab-pane fade" id="addresst" role="tabpanel" aria-labelledby="contact-tab">
            @include('school.partials.address')
        </div>
        <div class="tab-pane fade" id="info" role="tabpanel" aria-labelledby="contact-tab">
            @include('school.partials.notes')
        </div>
      </div>
      <div class="form-group">
          <a href="{{route('home') }}" class="btn btn-light float-right">Cancel</a>
          <button type="submit" class="btn btn-primary float-right">Save</button>
      </div>
    
    
</div>

@endsection

@section('extrajs')
@include('school.js')
@endsection