<div class="row">
    <div class="col-md-6">
        <div style="width: 300px; margin: 0 auto">
            <img src="/pic.png" style="width:100%; margin: 0 auto; cursor: pointer" id="picImage" />
            <input type="hidden" id="phototext" value="" />
            <input type="hidden" id="photodataurl" name="photodataurl" />
            <small><em>Click the image above to Add/Change</em></small>
            <input type="file" name="photo" id="photo" class="form-control {{ $errors->has('photo') ? 'is-invalid' : '' }}" style="display: none"
                accept="image/jpeg" />
            @if ($errors->has('photo'))
            <span class="required" role="alert">
                <br><strong>{{ $errors->first('photo') }}</strong>
            </span>
            @endif
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="name">School Name</label>
            <input type="text" id="name" name="name" class="form-control {{$errors->has('name') ? 'is-invalid': '' }}"
                value="{{old('name')}}">
            @if($errors->has('name'))
            <span class="invalid-feedback" role="alert">
                <strong>{{$errors->first('name') }}</strong>
            </span>
            @endif
        </div>
        <div class="form-group">
            <label for="principal">Principal</label>
            <input type="text" id="principal" name="principal" class="form-control {{$errors->has('principal') ? 'is-invalid': '' }}"
                value="{{old('principal') }}">
            @if($errors->has('principal'))
            <span class="invalid-feedback" role="alert">
                <strong>{{$errors->first('principal') }}</strong>
            </span>
            @endif
        </div>
    </div>
</div>