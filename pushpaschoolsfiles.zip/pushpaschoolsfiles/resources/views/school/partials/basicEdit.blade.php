<div class="row">
    <div class="col-md-6">
        @php
            $photo = $school->photo;
            if(!$photo) {
                $photo = 'pic.png';
            } else {
                $photo = 'storage/schoolpics/' . $photo;
            }
            $phototext = $photo == 'pic.png' ? '' : 'somephoto';
        @endphp
        <div style="width: 300px; margin: 0 auto">
            <img src="/{{$photo}}" style="width:100%; margin: 0 auto; cursor: pointer" id="picImage" />
            <input type="hidden" id="phototext" value="{{$phototext}}" />
            <input type="hidden" id="photodataurl" name="photodataurl" />
            <small><em>Click the image above to Add/Change</em></small>
            <input type="file" name="photo" id="photo" class="form-control {{ $errors->has('photo') ? 'is-invalid' : '' }}" style="display: none"
                accept="image/x-png,image/gif,image/jpeg" />
            @if ($errors->has('photo'))
            <span class="required" role="alert">
                <br><strong>{{ $errors->first('photo') }}</strong>
            </span>
            @endif
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="name">School Name</label>
            <input type="text" id="name" name="name" class="form-control {{$errors->has('name') ? 'is-invalid': '' }}"
                value="{{old('name') ?? $school->name}}">
            @if($errors->has('name'))
            <span class="invalid-feedback" role="alert">
                <strong>{{$errors->first('name') }}</strong>
            </span>
            @endif
        </div>
        <div class="form-group">
            <label for="principal">Principal</label>
            <input type="text" id="principal" name="principal" class="form-control {{$errors->has('principal') ? 'is-invalid': '' }}"
                value="{{old('principal') ?? $school->principal }}">
            @if($errors->has('principal'))
            <span class="invalid-feedback" role="alert">
                <strong>{{$errors->first('principal') }}</strong>
            </span>
            @endif
        </div>
    </div>
</div>