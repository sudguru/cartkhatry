<div class="row">
  <div class="col-md-6">
      <div class="form-group">
          <label for="address">Address</label>
          <input type="text" name="address" id="address" value="{{old('address') }}" class="form-control {{$errors->has('address') ? 'is-invalid' : '' }}">
          @if($errors->has('address'))
          <span class="invalid-feedback" role="alert">
              <strong>{{$errors->first('address') }}</strong>
          </span>
          @endif
      </div>
  </div>
  <div class="col-md-6">
      <div class="form-group">
          <label for="ward_no">Ward No</label>
          <input type="number" id="ward_no" name="ward_no" class="form-control {{$errors->has('ward_no') ? 'is-invalid': '' }}"
              value="{{old('ward_no')}}">
          @if($errors->has('ward_no'))
          <span class="invalid-feedback" role="alert">
              <strong>{{$errors->first('ward_no') }}</strong>
          </span>
          @endif
      </div>
  </div>
</div>
<div class="row">
  <div class="col-md-6">
      <div class="form-group">
          <label for="office_no">Office Number</label>
          <input type="text" name="office_no" id="office_no" value="{{old('office_no') }}" class="form-control {{$errors->has('office_no') ? 'is-invalid' : '' }}">
          @if($errors->has('office_no'))
          <span class="invalid-feedback" role="alert">
              <strong>{{$errors->first('office_no') }}</strong>
          </span>
          @endif
      </div>
  </div>
  <div class="col-md-6">
      <div class="form-group">
          <label for="mobile_no">Mobile Number</label>
          <input type="text" name="mobile_no" id="mobile_no" value="{{old('mobile_no') }}" class="form-control {{$errors->has('mobile_no') ? 'is-invalid' : '' }}">
          @if($errors->has('mobile_no'))
          <span class="invalid-feedback" role="alert">
              <strong>{{$errors->first('mobile_no') }}</strong>
          </span>
          @endif
      </div>
  </div>
</div>
<div class="row">
  <div class="col-md-6">
      <div class="form-group">
          <label for="email">Email</label>
          <input type="email" name="email" id="email" value="{{old('email') }}" class="form-control {{$errors->has('email') ? 'is-invalid' : '' }}">
          @if($errors->has('email'))
          <span class="invalid-feedback" role="alert">
              <strong>{{$errors->first('email') }}</strong>
          </span>
          @endif
      </div>
  </div>
  <div class="col-md-6">
      <div class="form-group">
          <label for="post_box">Post Box</label>
          <input type="text" name="post_box" id="post_box" value="{{old('post_box') }}" class="form-control {{$errors->has('post_box') ? 'is-invalid' : '' }}">
          @if($errors->has('post_box'))
          <span class="invalid-feedback" role="alert">
              <strong>{{$errors->first('post_box') }}</strong>
          </span>
          @endif
      </div>
  </div>
</div>
<div class="row">
  <div class="col-md-6">
      <div class="form-group">
          <label for="contact_person">Contact Person</label>
          <input type="text" name="contact_person" id="contact_person" value="{{old('contact_person') }}" class="form-control {{$errors->has('contact_person') ? 'is-invalid' : '' }}">
          @if($errors->has('contact_person'))
          <span class="invalid-feedback" role="alert">
              <strong>{{$errors->first('contact_person') }}</strong>
          </span>
          @endif
      </div>
  </div>
  <div class="col-md-6">
      <div class="form-group">
          <label for="contact_no">Contact No.</label>
          <input type="text" name="contact_no" id="contact_no" value="{{old('contact_no') }}" class="form-control {{$errors->has('contact_no') ? 'is-invalid' : '' }}">
          @if($errors->has('contact_no'))
          <span class="invalid-feedback" role="alert">
              <strong>{{$errors->first('contact_no') }}</strong>
          </span>
          @endif
      </div>
  </div>
</div>
<div class="row">
  <div class="col-md-6">
      <div class="form-group">
          <label for="home_no">Home No.</label>
          <input type="text" name="home_no" id="home_no" value="{{old('home_no') }}" class="form-control {{$errors->has('home_no') ? 'is-invalid' : '' }}">
          @if($errors->has('home_no'))
          <span class="invalid-feedback" role="alert">
              <strong>{{$errors->first('home_no') }}</strong>
          </span>
          @endif
      </div>
  </div>
  <div class="col-md-6">
        <div class="form-group">
            <label for="website">Website</label>
            <input type="text" name="website" id="website" value="{{old('website') }}" class="form-control {{$errors->has('website') ? 'is-invalid' : '' }}">
            @if($errors->has('website'))
            <span class="invalid-feedback" role="alert">
                <strong>{{$errors->first('website') }}</strong>
            </span>
            @endif
        </div>
  </div>
</div>