<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="municipality_id">Municipality</label>
            @php
            $selected_municipality_id = old('municipality_id') ?? $school->municipality_id;
            @endphp
            <select name="municipality_id" id="municipality_id" class="form-control {{$errors->has('municipality_id') ? 'is-invalid': '' }}">
                <option value="0" {{old('municipality_id') == '0' ? 'selected' : ''}}>Select Municipality</option>
                @foreach($municipalities as $municipality)
                <option value="{{$municipality->id}}"
                    {{ $selected_municipality_id == $municipality->id ? 'selected' : ''}}>
                    {{$municipality->municipality}}</option>
                @endforeach
            </select>
            @if($errors->has('municipality_id'))
            <span class="invalid-feedback" role="alert">
                <strong>{{$errors->first('municipality_id') }}</strong>
            </span>
            @endif
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="estd">ESTD</label>
            <input type="number" name="estd" id="estd" value="{{old('estd') ?? $school->estd }}" class="form-control {{$errors->has('estd') ? 'is-invalid' : '' }}">
            @if($errors->has('estd'))
            <span class="invalid-feedback" role="alert">
                <strong>{{$errors->first('estd') }}</strong>
            </span>
            @endif
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="cluster_id">Cluster</label>
            @php
            $selected_cluster_id = old('cluster_id') ?? $school->cluster_id;
            @endphp
            <select name="cluster_id" id="cluster_id" class="form-control {{$errors->has('cluster_id') ? 'is-invalid': '' }}">
                <option value="0" {{old('cluster_id') == '0' ? 'selected' : ''}}>Select Cluster</option>
                @foreach($clusters as $cluster)
                <option value="{{$cluster->id}}" {{ $selected_cluster_id == $cluster->id ? 'selected' : ''}}>
                    {{$cluster->cluster}}</option>
                @endforeach
            </select>
            @if($errors->has('cluster_id'))
            <span class="invalid-feedback" role="alert">
                <strong>{{$errors->first('cluster_id') }}</strong>
            </span>
            @endif
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="classes_upto">Classes Upto</label>
            <input type="number" id="classes_upto" name="classes_upto" class="form-control {{$errors->has('classes_upto') ? 'is-invalid': '' }}"
                value="{{old('classes_upto') ?? $school->classes_upto}}">
            @if($errors->has('classes_upto'))
            <span class="invalid-feedback" role="alert">
                <strong>{{$errors->first('classes_upto') }}</strong>
            </span>
            @endif
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="resourcecenter_id">Resource Center</label>
            @php
            $selected_resourcecenter_id = old('resourcecenter_id') ?? $school->resourcecenter_id;
            @endphp
            <select name="resourcecenter_id" id="resourcecenter_id" class="form-control {{$errors->has('resourcecenter_id') ? 'is-invalid': '' }}">
                <option value="0" {{old('resourcecenter_id') == '0' ? 'selected' : ''}}>Select Resouce Center</option>
                @foreach($resourcecenters as $resourcecenter)
                <option value="{{$resourcecenter->id}}"
                    {{ $selected_resourcecenter_id == $resourcecenter->id ? 'selected' : ''}}>
                    {{$resourcecenter->resourcecenter}}</option>
                @endforeach
            </select>
            @if($errors->has('resourcecenter_id'))
            <span class="invalid-feedback" role="alert">
                <strong>{{$errors->first('resourcecenter_id') }}</strong>
            </span>
            @endif
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="school_type">School Type</label>
            @php
                $school_type = old('school_type') ?? $school->school_type;
            @endphp
            <select name="school_type" id="school_type" class="form-control">
                <option value="Private" {{ $school_type == 'Private' ? 'selected' : '' }}>Private</option>
                <option value="Public" {{ $school_type == 'Public' ? 'selected' : '' }}>Public</option>
            </select>
        </div>
    </div>
</div>
<div class="row">

    <div class="col-md-6">
        <div class="form-group">
            <label for="cdo">CDO</label>
            <input type="text" name="cdo" id="cdo" value="{{old('cdo') ?? $school->cdo }}" class="form-control {{$errors->has('cdo') ? 'is-invalid' : '' }}">
            @if($errors->has('cdo'))
            <span class="invalid-feedback" role="alert">
                <strong>{{$errors->first('cdo') }}</strong>
            </span>
            @endif
        </div>
    </div>
</div>