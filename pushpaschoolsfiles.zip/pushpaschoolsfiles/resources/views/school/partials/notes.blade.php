<div class="row">
  <div class="col-md-12">
      <div class="form-group">
          <label for="notes">Notes</label>
          <textarea class="form-control editor" name="notes" id="notes">{{ old('notes') }}</textarea>
      </div>
  </div>
</div>