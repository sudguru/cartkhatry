<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{$school->name}}</title>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>

<body style="background-color: #ffffff">
    <div class="container mt-5" style="font-size: 120%">
        <div class="row">
            <div class="col-md-12">
                <h3>{{$school->name}}</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-12">
                        <small>Principal</small><br />
                        {{$school->principal}}<br />
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <small>Municipality</small><br />
                        {{$school->municipality['municipality']}}<br />
                        <small>Cluster</small><br />
                        {{$school->cluster['cluster']}}<br />
                        <small>Resource Center</small><br />
                        {{$school->resourcecenter['resourcecenter']}}<br />
                        <small>CDO</small><br />
                        {{$school->cdo}}<br />
                    </div>
                    <div class="col-md-6">
                        <small>ESTD</small><br />
                        {{$school->estd}}<br />
                        <small>Classes Upto</small><br />
                        {{$school->clsses_up}}<br />
                        <small>School Type</small><br />
                        {{$school->school_type}}<br />
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h4>Address</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <small>Address</small><br />
                        {{$school->address}}<br />
                        <small>Office No.</small><br />
                        {{$school->office_no}}<br />
                        <small>Contact Person</small><br />
                        {{$school->contact_person}}<br />
                        <small>Email</small><br />
                        {{$school->email}}<br />
                        <small>Home No.</small><br />
                        {{$school->home_no}}<br />
                    </div>
                    <div class="col-md-6">
                        <small>Ward No</small><br />
                        {{$school->ward_no}}<br />
                        <small>Mobile No.</small><br />
                        {{$school->mobile_no}}<br />
                        <small>Post Box</small><br />
                        {{$school->post_box}}<br />
                        <small>Contact No.</small><br />
                        {{$school->contact_no}}<br />
                        <small>Website</small><br />
                        {{$school->website}}<br />
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                @php
                $photo = $school->photo;
                if(!$photo) {
                $photo = '/pic.png';
                } else {
                $photo = '/storage/schoolpics/' . $photo;
                }
                @endphp
                <img src="{{$photo}}"" style=" width: 100%" />
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <h4>Additional Information</h4>
                {!!$school->notes!!}
            </div>
        </div>
    </div>

</body>

</html>