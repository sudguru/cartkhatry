@extends('layouts.app')
@section('pagetitle')
Schools
@endsection

@section('extracss')
<link rel="stylesheet" href="{{ asset('/css/snackbar.css') }}">
<link rel="stylesheet" href="{{ asset('/css/bs4datatables.min.css') }}">
<link rel="stylesheet" href="{{ asset('/css/button.datatables.min.css') }}">
@endsection

@section('content')
@if ($message = Session::get('success'))
<div id="snackbar">{{ $message }}</div>
@endif
    <div class="d-flex align-items-center mb-3">
        <h3>Schools</h3>
        <a class="btn btn-sm btn-primary ml-auto" href="{{route('school.create') }}">NEW</a>
    </div>
    <table class="table table-striped mt-3" id="mySchools">
        <thead>
            <th>SN</th>
            <th>Name</th>
            <th>Principal</th>
            <th>Municipality</th>
            <th>Ward</th>
            <th>Address</th>
            <th>Office</th>
            <th>Mobile</th>
            <th>Upto</th>
            <th>Cluster</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Number</th>
            <th>ESTD</th>
            <th>POBox</th>
            <th>Home</th>
            <th>CDO</th>
            <th>Res. Cent.</th>
            <th>Type</th>
            <th>Website</th>
            <th>Photo</th>
        </thead>
        <tbody>
            @foreach($schools as $key=>$school)
            <tr>
                <td>{{$key+1}}</td>
                <td>{{$school->name}}</td>
                <td>{{$school->principal}}</td>
                <td>{{$school->municipality['municipality']}}</td>
                <td>{{$school->ward_no}}</td>
                <td>{{$school->address}}</td>
                <td>{{$school->office_no}}</td>
                <td>{{$school->mobile_no}}</td>
                <td>{{$school->classes_upto}}</td>
                <td>{{$school->cluster['cluster']}}</td>
                <td>{{$school->email}}</td>
                <td>{{$school->contact_person}}</td>
                <td>{{$school->contact_no}}</td>
                <td>{{$school->estd}}</td>
                <td>{{$school->post_box}}</td>
                <td>{{$school->home_no}}</td>
                <td>{{$school->cdo}}</td>
                <td>{{$school->resourcecenter['resourcecenter']}}</td>
                <td>{{$school->school_type}}</td>
                <td>{{$school->website}}</td>
                <td>{{$school->photo}}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <hr>
    <div id="output"></div>
@endsection

@section('extrajs')
<style>
    .myclass {
        display: flex;
        justify-content: space-between;
    }
</style>
<script src="{{ asset('js/bs4datatables.min.js') }}"></script>
<script src="{{ asset('js/datatablebutton.min.js') }}"></script>
<script src="{{ asset('js/datatablecolvis.min.js') }}"></script>
<script src="{{ asset('js/datatableprint.min.js') }}"></script>
<script>
    $(document).ready(function() {
    var filtered_rows;
    var filtered_rows_array = [];
    var table = $('#mySchools').DataTable( {
        dom: '<"myclass"Bf>rt<"myclass"lip>',
        buttons: [
            {
                extend: 'print',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                text: 'Print(With Photo)',
                action: function ( e, dt, node, config ) {
                    items = table.rows( { filter : 'applied'} ).nodes().length;
                    filtered_rows = table.rows( { filter : 'applied'} ).data();
                    filtered_rows_array = [];
                    for(i = 0; i < items; i++) {
                        filtered_rows_array.push(filtered_rows[i]);
                        console.log(i);
                    }
                    localStorage.setItem('printdata', JSON.stringify(filtered_rows_array));
                    window.open("/printwithimage", "_blank");
                }
            },
            {
                extend: 'colvis',
                collectionLayout: 'fixed three-column',
                postfixButtons: [ 'colvisRestore' ]
            }
        ],
        columnDefs: [
            {
                targets: [-1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12],
                visible: false
            }
        ]
    } );




} );


</script>
<script>
    var x = document.getElementById("snackbar");
    if (x) {
        x.className = "show";
        setTimeout(function () {
            x.className = x.className.replace("show", "");
        }, 3000);
    }

</script>
@endsection
