<script src="{{ asset('js/summernote.min.js') }}"></script>
<script>
    $(document).ready(function () {
        $('#notes').summernote({
            height: 150,
            toolbar: [
                // [groupName, [list of button]]
                ['style', ['bold', 'italic', 'underline', 'clear']],
                ['font', ['strikethrough', 'superscript', 'subscript']],
                ['fontsize', ['fontsize']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['insert', ['link', 'picture', 'video', 'table', 'hr']],
                ['height', ['height']],
                ['fullscreen']
            ]
        });
        $('#picImage').on('click', function () {
            $('#photo').click();
        });

        ///************ 
        checkAndSet();

        function checkAndSet() {
            var groupBasic = ['name', 'principal', 'phototext'];
            var groupOfficial = ['municipality_id', 'estd', 'cluster_id', 'resourcecenter_id', 'classes_upto', 'cdo', 'school_type'];
            var groupAddress = ['address', 'office_no', 'mobile_no', 'post_box', 'contact_person', 'contact_no', 'home_no', 'ward_no', 'email', 'website']
            var groupInfo = ['notes'];
            var b = 0;
            groupBasic.forEach(function(item) {
            b += check(item);
            });
            var o = 0;
            groupOfficial.forEach(function(item) {
                o += check(item);
            });
            var a = 0;
            groupAddress.forEach(function(item) {
                a += check(item);
            });
            var i = 0;
            groupInfo.forEach(function(item) {
                i += check(item);
            });
            setAll(b,o,a,i);
        }
        

        // $('.form-control').on('change', function() {
        //     checkAndSet();
        // })
        setInterval(function() {
            console.log('checked');
            checkAndSet();
        }, 2000);

        function setAll(b,o,a,i) {
            $('#basic-progress').html(b+'/3');
            $('#official-progress').html(o+'/7');
            $('#address-progress').html(a+'/10');
            $('#info-progress').html(i+'/1');
        }
        function check(field) {
            var v = $('#'+field).val();
            return (v && v != '0') ? 1 : 0;
        }

        ///*********

        $('#photo').on('change', function (e) {
            document.getElementById('phototext').value = 'somephoto';
            var file = document.getElementById('photo').files[0];
            var picImage = document.getElementById('picImage');
            var reader = new FileReader();
            reader.onload = function (e) {
                imageDataURL = e.target.result;
                
                  var image = new Image();
                  image.src = imageDataURL;
                  image.onload = function (imageEvent) {
                      // Resize the image
                      var canvas = document.createElement('canvas'),
                          max_size = 300,
                          width = image.width,
                          height = image.height;
                      if (width > height) {
                          if (width > max_size) {
                              height *= max_size / width;
                              width = max_size;
                          }
                      } else {
                          if (height > max_size) {
                              width *= max_size / height;
                              height = max_size;
                          }
                      }
                      canvas.width = width;
                      canvas.height = height;
                      canvas.getContext('2d').drawImage(image, 0, 0, width, height);
                      var dataUrl = canvas.toDataURL('image/jpeg');
                      picImage.src = dataUrl;
                      $('#photodataurl').val(dataUrl);
                }

            }
            reader.readAsDataURL(file);
            });

    });
</script>