@extends('layouts.app')
@section('pagetitle')
Dashboard
@endsection

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h4>Welcome</h4>
            <table class="table">
                <tr>
                    <th>No of School</th>
                    <td>{{$schools->count()}}</td>
                </tr>
                <tr>
                    <td colspan="2">
                        <a href="{{route('school.index')}}"><i class="fas fa-school"></i> View All Schools</a>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <a href="{{route('school.create')}}"><i class="fas fa-plus"></i> Add New School</a>
                    </td>
                </tr>
                <tr>
                    <td>
                        <select id="school_id" class="form-control">
                            <option value="0">Select School To Edit</option>
                            @foreach ($schools as $key=>$school)
                            <option value="{{$key}}">{{$school}}</option>
                            @endforeach
                        </select>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-success eye mt-1"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-sm btn-warning edit mt-1"><i class="fas fa-edit"></i></button>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <a href="{{route('manageimage')}}"><i class="fas fa-image"></i> Manage Images</a>
                    </td>
                </tr>
            </table>

            <h4>Recently Added/Edited Schools</h4>
            {{-- <div id="recent"></div> --}}
            <table class="table">
                <thead>
                    <tr>
                        <th>SN</th>
                        <th>School</th>
                        <th>Task</th>
                        <th>When</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($recents as $key=>$recent)
                    <tr>
                        <td>{{$key+1}}</td>
                        <td>{{$recent->name}}</td>
                        <td>{{$recent->task}}</td>
                        <td>{{$recent->created_at->diffForHumans()}} </td>
                        <td>
                            @if($recent->task != 'Deleted')
                            <a href="{{ route('school.show', $recent->school_id) }}" target='_blank' class="btn btn-link">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="{{ route('school.edit', $recent->school_id) }}" class="btn btn-link">
                                <i class="fas fa-edit"></i>
                            </a>
                            @endif
                        </td>
                    </tr>
                    @endforeach

                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

@section('extrajs')
<script>
    $(document).ready(function () {
        $('.edit').on('click', function () {
            var school_id = $('#school_id').val();
            if (school_id == "0") return;
            location.href = '/school/' + school_id + '/edit';
        });
        $('.eye').on('click', function () {
            var school_id = $('#school_id').val();
            if (school_id == "0") return;
            window.open('/school/' + school_id, '_blank');
        });


    });

</script>
@endsection
