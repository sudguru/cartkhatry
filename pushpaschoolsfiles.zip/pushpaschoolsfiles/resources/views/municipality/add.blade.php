@extends('layouts.app')

@section('pagetitle')
Add New Municipality
@endsection

@section('content')
<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-8">
            <h3>Add New Municipality</h3>
            <form action="{{route('municipality.store')}}" method="POST">
                @csrf
                <div class="form-group mt-4">
                    <label for="municipality">Municipality</label>
                    <input id="municipality" name="municipality" value="{{old('municipality')}}" class="form-control {{ $errors->has('municipality') ? 'is-invalid' : '' }}" />
                    @if($errors->has('municipality'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{$errors->first('municipality') }}</strong>
                    </span>
                    @endif
                </div>

                <div class="form-group">
                    <label for="municipality_nepali">Municipality (In Nepali)</label>
                    <input id="municipality_nepali" name="municipality_nepali" value="{{old('municipality_nepali')}}"
                        class="form-control {{ $errors->has('municipality_nepali') ? 'is-invalid' : '' }}" />
                    @if($errors->has('municipality_nepali'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{$errors->first('municipality_nepali') }}</strong>
                    </span>
                    @endif
                </div>
                <button type="submit" class="btn btn-primary">Add</button>
                <a href="{{route('municipality.index')}}" class="btn btn-light">Cancel</a>
            </form>
        </div>
    </div>
</div>
@endsection