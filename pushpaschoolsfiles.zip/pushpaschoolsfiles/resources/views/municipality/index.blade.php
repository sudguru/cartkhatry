@extends('layouts.app')

@section('pagetitle')
    Municipalities
@endsection

@section('extracss')
<link rel="stylesheet" href="{{ asset('/css/snackbar.css') }}">
@endsection

@section('content')
<div class="container">
    @if ($message = Session::get('success'))
    <div id="snackbar">{{ $message }}</div>
    @endif
    <div class="d-flex align-items-center">
        <h3>Municipalities</h3>
        <a class="btn btn-sm btn-primary ml-auto" href="{{route('municipality.create') }}">NEW</a>
    </div>
    <div class="table-responsive mt-3">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>SN</th>
                    <th>Municipality</th>
                    <th>In Nepali</th>
                    <th>Del</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($municipalities as $key=>$municipality)
                    <tr>                      
                        <td>{{$key+1}}</td>
                        <td><a href="{{route('municipality.edit', $municipality->id) }}">{{$municipality->municipality}}</a></td>
                        <td>{{$municipality->municipality_nepali}}</td>
                        <td>
                            <a href="/municipality/{{ $municipality->id }}" onclick="event.preventDefault();
                            if ( confirm('You are about to delete this item ?\n \'Cancel\' to stop, \'OK\' to delete.') ) { document.getElementById('delete-form-{{$municipality->id}}').submit();}return false;">
                                <i class="fas fa-trash text-danger"></i>
                            </a>
                            <form id="delete-form-{{$municipality->id}}" action="/municipality/{{ $municipality->id }}" method="POST" style="display: none;">
                                @csrf
                                {{ method_field('delete') }}
                                <input type="hidden" name="id" value="{{ $municipality->id }}" />
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection

@section('extrajs')
<script>
        var x = document.getElementById("snackbar");
        if (x) {
            x.className = "show";
            setTimeout(function () {
                x.className = x.className.replace("show", "");
            }, 3000);
        } 
        </script>
@endsection