<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Schools</title>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <style>
        .outer {
            box-sizing: border-box;
            width: 500px;
            height: 320px;
            margin: 10px 10px;
            border-radius: 5px;
            border: 1px solid #efefef;
            float: left;
            padding: 15px;
            position: relative;
        }
        .bigger {
            font-size: 130%;
        }
        .smaller {
            font-size: 70%;
        }
    </style>
</head>
<body style="background-color: #fff">
    <script>
        var data = JSON.parse(localStorage.getItem('printdata'));
        
        data.forEach(function(row, i) {
            var photo = '';
            if(row[20].length > 4) {
                photo = '<img src="/storage/schoolpics/'+row[20]+'" style="width:100%" >';
            }
            item  = '<div class="outer">'+
                    '<h3>' + row[1] + '</h3>'+
                    '<div class="row bigger">'+
                        '<div class="col-8 pt-3">'+
                            '<strong>' + row[2] + '</strong> <br>' +
                            '<small class="smaller">Address. : </small><br/>' +
                            row[5] + '<br/>' +
                            '<small class="smaller">Office No. : </small>&nbsp;' +
                            row[6] + '<br/>' +
                            '<small class="smaller">Mobile No. : </small>&nbsp;' +
                            row[7] + '<br/>' +
                            '<small class="smaller">Email : </small>&nbsp;' +
                            row[10] + '<br/>' +
                        '</div>' +
                        '<div class="col-4 pt-3">' +
                            photo +
                        '</div>' +
                    '</div>' +
                '</div>';
            if((i%8) == 0) {
                document.write('<div style="page-break-after: always;"></div>');
            }
            document.write(item)
        })
        
    </script>
</body>
</html>