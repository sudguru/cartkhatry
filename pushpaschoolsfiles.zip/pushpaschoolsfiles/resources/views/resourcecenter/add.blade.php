@extends('layouts.app')

@section('pagetitle')
Add New Resource Center
@endsection

@section('content')
<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-8">
            <h3>Add New Resource Center</h3>
            <form action="{{route('resourcecenter.store')}}" method="POST">
                @csrf
                <div class="form-group mt-4">
                    <label for="resourcecenter">Resource Center</label>
                    <input id="resourcecenter" name="resourcecenter" value="{{old('resourcecenter')}}" class="form-control {{ $errors->has('resourcecenter') ? 'is-invalid' : '' }}" />
                    @if($errors->has('resourcecenter'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{$errors->first('resourcecenter') }}</strong>
                    </span>
                    @endif
                </div>

                <div class="form-group">
                    <label for="resourcecenter_nepali">Resource Center (In Nepali)</label>
                    <input id="resourcecenter_nepali" name="resourcecenter_nepali" value="{{old('resourcecenter_nepali')}}"
                        class="form-control {{ $errors->has('resourcecenter_nepali') ? 'is-invalid' : '' }}" />
                    @if($errors->has('resourcecenter_nepali'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{$errors->first('resourcecenter_nepali') }}</strong>
                    </span>
                    @endif
                </div>
                <button type="submit" class="btn btn-primary">Add</button>
                <a href="{{route('resourcecenter.index')}}" class="btn btn-light">Cancel</a>
            </form>
        </div>
    </div>
</div>
@endsection