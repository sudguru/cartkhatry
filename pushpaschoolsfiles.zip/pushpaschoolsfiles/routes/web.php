<?php


Auth::routes();
Route::get('/', 'HomeController@index')->name('home');
Route::get('/manageimage', 'HomeController@manageimage')->name('manageimage');
Route::post('/setphoto', 'HomeController@setphoto');
Route::get('/printwithimage', 'HomeController@printwithimage');

Route::resource('school', 'SchoolController');
Route::resource('cluster', 'ClusterController');
Route::resource('municipality', 'MunicipalityController');
Route::resource('resourcecenter', 'ResourcecenterController');

